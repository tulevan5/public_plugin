//
// Created by jinglong cai on 2021/4/13.
//

#import <Foundation/Foundation.h>

@protocol PMConvertProtocol <NSObject>

- (id)convertData:(NSData *)data;

@end